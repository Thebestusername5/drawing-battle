const express = require("express");
const http = require("http");
const path = require("path");
const crypto = require("crypto");
const { WebSocketServer } = require("ws");

const app = express();
const server = http.createServer(app);
const PORT = Number(process.env.PORT) || 10000;
const rooms = new Map();
const PROMPTS = ["DOG","CAT","HOUSE","ROBOT","TREE","CAR","FISH","DRAGON","BIRD","PIZZA","CASTLE","GHOST","FLOWER","ROCKET","ALIEN","SHARK","MUSHROOM","CACTUS","MONSTER","SUN"];
const TOTAL_ROUNDS = 5;
const ROUND_SECONDS = 45;

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, rooms: rooms.size }));

const wss = new WebSocketServer({ server });
function send(ws, data) { if (ws.readyState === 1) ws.send(JSON.stringify(data)); }
function broadcast(room, data) { room.players.forEach(p => send(p.ws, data)); }
function roomCode() { let c; do { c = crypto.randomBytes(3).toString("hex").toUpperCase(); } while (rooms.has(c)); return c; }
function shuffledPrompts() { return [...PROMPTS].sort(() => Math.random() - 0.5).slice(0, TOTAL_ROUNDS); }

function startRound(room) {
  if (room.players.length !== 2) return;
  room.roundStarted = true;
  room.ends = Date.now() + ROUND_SECONDS * 1000;
  room.players.forEach(p => { p.strokes = []; p.finished = false; });
  broadcast(room, { type:"round_start", round:room.round, totalRounds:TOTAL_ROUNDS, prompt:room.prompts[room.round - 1], seconds:ROUND_SECONDS });
}

function endRound(room, reason) {
  if (!room.roundStarted) return;
  room.roundStarted = false;
  const results = room.players.map(p => ({ id:p.id, name:p.name, strokes:p.strokes.length }));
  broadcast(room, { type:"round_end", round:room.round, reason, results });
  if (room.round >= TOTAL_ROUNDS) {
    setTimeout(() => {
      if (rooms.get(room.code) !== room) return;
      const final = room.players.map(p => ({ id:p.id, name:p.name, score:p.score }));
      broadcast(room, { type:"game_end", results:final });
    }, 3000);
  } else {
    room.round += 1;
    setTimeout(() => { if (rooms.get(room.code) === room && room.players.length === 2) startRound(room); }, 3500);
  }
}

wss.on("connection", ws => {
  ws.id = crypto.randomBytes(8).toString("hex");
  ws.isAlive = true;
  ws.on("pong", () => ws.isAlive = true);
  send(ws, { type:"connected", id:ws.id });

  ws.on("message", raw => {
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    if (m.type === "create_room") {
      if (ws.roomCode) return;
      const code = roomCode();
      const player = { id:ws.id, ws, name:String(m.name || "Player").trim().slice(0,20) || "Player", strokes:[], score:0, finished:false };
      const room = { code, players:[player], prompts:shuffledPrompts(), round:1, roundStarted:false, ends:0 };
      rooms.set(code, room); ws.roomCode = code;
      send(ws, { type:"room_created", code, playerId:ws.id });
      return;
    }
    if (m.type === "join_room") {
      const code = String(m.code || "").toUpperCase();
      const room = rooms.get(code);
      if (!room) return send(ws, { type:"error", message:"Room not found." });
      if (room.players.length >= 2) return send(ws, { type:"error", message:"Room is full." });
      const player = { id:ws.id, ws, name:String(m.name || "Player 2").trim().slice(0,20) || "Player 2", strokes:[], score:0, finished:false };
      room.players.push(player); ws.roomCode = code;
      broadcast(room, { type:"room_joined", players:room.players.map(p => ({id:p.id,name:p.name})) });
      setTimeout(() => startRound(room), 1000);
      return;
    }
    const room = rooms.get(ws.roomCode);
    if (!room || !room.roundStarted) return;
    const player = room.players.find(p => p.ws === ws);
    if (!player) return;

    if (m.type === "stroke" && m.stroke) {
      if (player.strokes.length >= 30000) return;
      const s = m.stroke;
      const stroke = { x1:clamp(s.x1), y1:clamp(s.y1), x2:clamp(s.x2), y2:clamp(s.y2), size:Math.max(1,Math.min(80,Number(s.size)||10)), tool:s.tool === "eraser" ? "eraser" : "brush" };
      player.strokes.push(stroke);
      room.players.filter(p => p.ws !== ws).forEach(p => send(p.ws, { type:"opponent_stroke", stroke }));
    } else if (m.type === "clear") {
      player.strokes = [];
      room.players.filter(p => p.ws !== ws).forEach(p => send(p.ws, { type:"opponent_clear" }));
    } else if (m.type === "finish_drawing") {
      if (player.finished) return;
      player.finished = true;
      player.score += 100 + Math.max(0, Math.floor((room.ends - Date.now()) / 1000));
      if (room.players.every(p => p.finished)) endRound(room, "both_finished");
    }
  });

  ws.on("close", () => {
    const room = rooms.get(ws.roomCode);
    if (!room) return;
    room.players = room.players.filter(p => p.ws !== ws);
    if (!room.players.length) rooms.delete(room.code);
    else { room.roundStarted = false; broadcast(room, { type:"opponent_left" }); }
  });
});

function clamp(value) { const n = Number(value); return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0; }
setInterval(() => { for (const room of rooms.values()) if (room.roundStarted && Date.now() >= room.ends) endRound(room, "time"); }, 250);
setInterval(() => { for (const ws of wss.clients) { if (!ws.isAlive) { ws.terminate(); } else { ws.isAlive = false; ws.ping(); } } }, 30000);
server.listen(PORT, "0.0.0.0", () => console.log(`Drawing Battle listening on ${PORT}`));
