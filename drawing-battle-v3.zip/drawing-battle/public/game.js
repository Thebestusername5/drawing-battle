const $=id=>document.getElementById(id);const screens=['home','lobby','game','vote','results','final'];
const S={ws:null,id:null,code:'',name:'Player',players:[],me:null,tool:'brush',strokes:[],redo:[],drawing:false,last:null,round:0,endsAt:0,voted:false};
const canvas=$('canvas'),ctx=canvas.getContext('2d');ctx.lineCap='round';ctx.lineJoin='round';
function show(id){screens.forEach(x=>$(x).classList.toggle('active',x===id));}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function send(o){if(S.ws&&S.ws.readyState===1)S.ws.send(JSON.stringify(o));}
function connect(){if(S.ws)return;S.ws=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host);$('conn').textContent='CONNECTING';S.ws.onopen=()=>{$('conn').textContent='ONLINE'};S.ws.onclose=()=>{$('conn').textContent='OFFLINE';S.ws=null};S.ws.onmessage=e=>handle(JSON.parse(e.data));}
function handle(m){
 if(m.type==='error'){alert(m.message);return}
 if(m.type==='room_created'||m.type==='room_joined'){S.id=m.id;S.code=m.code||S.code;$('roomCode').textContent=S.code;show('lobby');return}
 if(m.type==='room_state'){S.code=m.code;S.round=m.round;S.players=m.players||[];renderPlayers(); if(m.phase==='drawing')show('game');return}
 if(m.type==='player_list'){S.players=m.players||[];renderPlayers();renderGamePlayers();return}
 if(m.type==='round_start'){S.done=false;$('done').disabled=false;S.round=m.round;S.endsAt=m.endsAt;S.players=m.players||[];S.strokes=[];S.redo=[];S.voted=false;clearCanvas();$('round').textContent=S.round;$('prompt').textContent=m.prompt;$('doneBanner').classList.add('hidden');show('game');renderGamePlayers();return}
 if(m.type==='opponent_stroke'){return}
 if(m.type==='opponent_state'){return}
 if(m.type==='you_are_done'){$('doneBanner').classList.remove('hidden');return}
 if(m.type==='voting_start'){renderVoting(m.drawings||[],m.prompt);show('vote');return}
 if(m.type==='vote_registered'){$('voteStatus').textContent='Vote locked in ✓';return}
 if(m.type==='round_results'){renderResults(m.ranking||[]);show('results');return}
 if(m.type==='game_end'){renderFinal(m.ranking||[]);show('final');return}
 if(m.type==='chat'){addChat(m.name,m.text);return}
 if(m.type==='kicked'){alert('You were kicked from the room.');location.reload();return}
 if(m.type==='opponent_left'){addChat('SYSTEM',m.name+' left the room.');return}
}
function renderPlayers(){ $('count').textContent=`${S.players.length}/4`;$('players').innerHTML=S.players.map(p=>`<div class="player"><div class="avatar">${esc(p.name[0]||'?')}</div><div class="player-name">${esc(p.name)} ${p.host?'<span class="host">HOST</span>':''}</div><div class="ready-state ${p.ready?'on':''}">${p.ready?'READY':'NOT READY'}</div>${S.me&&S.me.host&&!p.host?`<button onclick="kick('${p.id}')">KICK</button>`:''}</div>`).join('');S.me=S.players.find(p=>p.id===S.id)||S.me;if(S.me&&S.me.host){$('start').classList.remove('hidden');$('ready').classList.add('hidden')}else{$('start').classList.add('hidden');$('ready').classList.remove('hidden')}}
function renderGamePlayers(){ $('gamePlayers').innerHTML=S.players.map(p=>`<div class="score-chip"><b>${esc(p.name)}</b><div class="small">${p.score||0} pts ${p.done?'• DONE':''}</div></div>`).join(''); }
function addChat(name,text){['chatLog','gameChat'].forEach(id=>{const box=$(id);box.insertAdjacentHTML('beforeend',`<div class="chat-msg"><b>${esc(name)}:</b> ${esc(text)}</div>`);box.scrollTop=box.scrollHeight})}
function sendChat(id){const input=$(id);if(input.value.trim()){send({type:'chat',text:input.value});input.value=''}}
function setupCanvas(){canvas.addEventListener('pointerdown',e=>{if(S.done)return;canvas.setPointerCapture(e.pointerId);S.drawing=true;S.last=pos(e);S.strokes.push({points:[S.last],color:$('color').value,size:+$('size').value,tool:S.tool});S.redo=[]});canvas.addEventListener('pointermove',e=>{if(!S.drawing)return;const p=pos(e),st=S.strokes.at(-1);const d=Math.hypot(p.x-S.last.x,p.y-S.last.y);if(d<1)return;st.points.push(p);drawStrokeSegment(S.last,p,st);S.last=p});canvas.addEventListener('pointerup',endStroke);canvas.addEventListener('pointercancel',endStroke)}
function pos(e){const r=canvas.getBoundingClientRect();return {x:(e.clientX-r.left)/r.width*canvas.width,y:(e.clientY-r.top)/r.height*canvas.height}}
function endStroke(){if(!S.drawing)return;S.drawing=false;S.last=null;send({type:'stroke',stroke:S.strokes.at(-1)})}
function drawStrokeSegment(a,b,s){ctx.save();ctx.globalCompositeOperation=s.tool==='eraser'?'destination-out':'source-over';ctx.strokeStyle=s.color;ctx.lineWidth=s.size;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.restore()}
function redraw(){ctx.clearRect(0,0,canvas.width,canvas.height);for(const s of S.strokes){for(let i=1;i<s.points.length;i++)drawStrokeSegment(s.points[i-1],s.points[i],s)}}
function clearCanvas(){S.strokes=[];S.redo=[];redraw()}
function snapshot(){return JSON.parse(JSON.stringify(S.strokes))}
function restore(a){S.strokes=a;redraw();send({type:'state',strokes:S.strokes})}
function kick(id){send({type:'kick',playerId:id})}
function renderVoting(drawings,prompt){$('voteStatus').textContent='';$('drawings').innerHTML='';drawings.forEach(d=>{const card=document.createElement('div');card.className='drawing-card';card.innerHTML=`<b>${esc(d.name)}</b><canvas width="500" height="350"></canvas><button class="primary" ${d.id===S.id?'disabled':''}>VOTE FOR THIS DRAWING</button>`;const c=card.querySelector('canvas'),cx=c.getContext('2d');cx.lineCap='round';cx.lineJoin='round';for(const s of d.strokes||[]){cx.save();cx.globalCompositeOperation=s.tool==='eraser'?'destination-out':'source-over';cx.strokeStyle=s.color;cx.lineWidth=s.size/2;for(let i=1;i<s.points.length;i++){cx.beginPath();cx.moveTo(s.points[i-1].x/2,s.points[i-1].y/2);cx.lineTo(s.points[i].x/2,s.points[i].y/2);cx.stroke()}cx.restore()}if(d.id!==S.id)card.querySelector('button').onclick=()=>{if(!S.voted){S.voted=true;send({type:'vote',targetId:d.id});document.querySelectorAll('#drawings button').forEach(b=>b.disabled=true);$('voteStatus').textContent='Vote submitted ✓'}};else card.querySelector('button').textContent='YOUR DRAWING';$('drawings').appendChild(card)})}
function renderResults(list){$('resultsList').innerHTML=list.map((p,i)=>`<div class="result-row"><div class="rank">#${i+1}</div><div class="rname"><b>${esc(p.name)}</b><div class="small-muted">${p.votes} vote${p.votes===1?'':'s'}</div></div><div class="points">+${p.roundScore} • ${p.totalScore}</div></div>`).join('')}
function renderFinal(list){$('finalList').innerHTML=list.map((p,i)=>`<div class="result-row"><div class="rank">#${i+1}</div><div class="rname"><b>${esc(p.name)}</b></div><div class="points">${p.totalScore} PTS</div></div>`).join('')}
$('showJoin').onclick=()=>{$('joinBox').classList.toggle('hidden');$('code').focus()};
$('create').onclick=()=>{S.name=$('name').value.trim()||'Player';connect();const wait=()=>{if(S.ws&&S.ws.readyState===1)send({type:'create_room',name:S.name});else setTimeout(wait,50)};wait()};
$('join').onclick=()=>{S.name=$('name').value.trim()||'Player';S.code=$('code').value.trim().toUpperCase();connect();const wait=()=>{if(S.ws&&S.ws.readyState===1)send({type:'join_room',name:S.name,code:S.code});else setTimeout(wait,50)};wait()};
$('ready').onclick=()=>{const me=S.players.find(p=>p.id===S.id);send({type:'ready',ready:!me?.ready});};$('start').onclick=()=>send({type:'start_game'});
$('copy').onclick=async()=>{await navigator.clipboard.writeText(location.href.split('?')[0]+'?room='+S.code);$('copy').textContent='COPIED ✓';setTimeout(()=>$('copy').textContent='COPY INVITE',1500)};
$('sendChat').onclick=()=>sendChat('chatInput');$('chatInput').onkeydown=e=>{if(e.key==='Enter')sendChat('chatInput')};$('gameSend').onclick=()=>sendChat('gameChatInput');$('gameChatInput').onkeydown=e=>{if(e.key==='Enter')sendChat('gameChatInput')};
document.querySelectorAll('.tool').forEach(b=>b.onclick=()=>{S.tool=b.dataset.tool;document.querySelectorAll('.tool').forEach(x=>x.classList.remove('active'));b.classList.add('active')});
$('undo').onclick=()=>{if(!S.strokes.length)return;S.redo.push(S.strokes.pop());redraw();send({type:'state',strokes:S.strokes})};$('redo').onclick=()=>{if(!S.redo.length)return;S.strokes.push(S.redo.pop());redraw();send({type:'state',strokes:S.strokes})};$('clear').onclick=()=>{if(confirm('Clear your drawing?'))clearCanvas();send({type:'state',strokes:[]})};$('done').onclick=()=>{if(!S.strokes.length){alert('Draw something first!');return}send({type:'done'});$('doneBanner').classList.remove('hidden');$('done').disabled=true};$('playAgain').onclick=()=>location.reload();
setInterval(()=>{if(S.endsAt&&$('game').classList.contains('active')){$('timer').textContent=Math.max(0,Math.ceil((S.endsAt-Date.now())/1000));}},100);
setupCanvas();const params=new URLSearchParams(location.search);if(params.get('room')){$('joinBox').classList.remove('hidden');$('code').value=params.get('room').toUpperCase()}
